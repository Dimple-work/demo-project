function signIn() {
	let userEmail = document.getElementById("userEmail").value;
	let userPassword = document.getElementById("userPassword").value;
  let getUserdata = JSON.parse(localStorage.getItem('Data'));
  let currentUser = getUserdata.filter((user) => user.Email === userEmail && user.Password === userPassword)[0];
  console.log(currentUser); 
}